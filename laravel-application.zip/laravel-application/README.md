
## Aplication console command

# Instruction 
- Créez la base de donnée "laravel_application"
- lancez le projet avce la commande 'php artisan serve'
- lancez la migration avec la commande 'php artisan migrate'
- lancez seeder avec la commande 'php artisan db.seed'
- lancez la commande d'affichages des posts à partir d'un tag donnée avec la commande 'php artisan show:posts  tag' 