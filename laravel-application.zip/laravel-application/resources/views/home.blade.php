@extends('layout')

@section('content')
     <h1>Home page</h1>
@endsection
   

