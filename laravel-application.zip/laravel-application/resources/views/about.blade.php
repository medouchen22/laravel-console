@extends('layout')

@section('content')
     <h1>About page</h1>
@endsection
   

